/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PROG06_Ejerc1;

import java.time.LocalDate;

/**
 * @author Ismael Argüelles
 */
public class Vehiculo {
    //Atributos de la clase
    private String marca;
    private String matricula;
    private int num_kilometros;
    private LocalDate fecha_matriculacion;
    private String descripcion;
    private float precio;
    private String nombre_propietario;
    private String dni_propietario;
    private boolean apto;
    
    /**
     * Constructor que crea el objeto que en nuestro caso es el vehículo
     * @param marca dato necesario para registrar al vehículo. Dato solicitado al usuario
     * @param matricula dato necesario para registrar al vehículo. Dato solicitado al usuario
     * @param num_kilometros dato necesario para registrar al vehículo. Dato solicitado al usuario
     * @param fecha_matriculacion dato necesario para registrar al vehículo. Dato solicitado al usuario
     * @param descripcion dato necesario para registrar al vehículo. Dato solicitado al usuario
     * @param precio dato necesario para registrar al vehículo. Dato solicitado al usuario
     * @param nombre_propietario dato necesario para registrar al vehículo. Dato solicitado al usuario
     * @param dni_propietario dato necesario para registrar al vehículo. Dato solicitado al usuario
     * @return devuelve true si la matrícula cumple con el patrón definido y false si no cumple con dicho formato
     */
    public Vehiculo (String marca, String matricula, int num_kilometros, LocalDate fecha_matriculacion, String descripcion, float precio, String nombre_propietario, String dni_propietario){
        this.marca=marca;
        this.matricula=matricula;
        this.num_kilometros=num_kilometros;
        this.fecha_matriculacion=fecha_matriculacion;
        this.descripcion=descripcion;
        this.precio=precio;
        this.nombre_propietario=nombre_propietario;
        this.dni_propietario=dni_propietario;
    }
    
    //Métodos get y set 
    /**
     * Método que muestra la marca del vehículo
     * @return devuelve la marca del vehículo
     */
    public String getMarca() {
        return marca;
    }
    
    /**
     * Método que modifica la marca del vehículo 
     * @param marca dato necesario para registrar la marca del vehículo
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    /**
     * Método que muestra la matrícula del vehículo
     * @return devuelve la matrícula del vehículo
     */
    public String getMatricula() {
        return matricula;
    }
    
    /**
     * Método que modifica la matrícula del vehículo
     * @param matricula dato necesario para registrar la matrícula del vehículo
     */
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    
    /**
     * Método que muestra el número de kilómetros del vehículo
     * @return devuelve el número de kilómetros del vehículo
     */
    public float getNum_kilometros() {
        return num_kilometros;
    }
    
    /**
     * Método que modifica el número de kilómetros del vehículo
     * @param num_kilometros dato necesario para registrar el número de kilómetros 
     * del vehículo
     */
    public void setNum_kilometros(int num_kilometros) {
        this.num_kilometros = num_kilometros;
    }
    
    /**
     * Método que muestra la fecha de matriculación del vehículo
     * @return devuelve la fecha de matriculación del vehículo
     */
    public LocalDate getFecha_matriculacion() {
        return fecha_matriculacion;
    }
    
    /**
     * Método que modifica la fecha de matriculación del vehículo
     * @param fecha_matriculacion dato necesario para registrar la fecha de matriculación
     * del vehículo
     */
    public void setFecha_matriculacion(LocalDate fecha_matriculacion) {
        this.fecha_matriculacion = fecha_matriculacion;
    }
    
    /**
     * Método que muestra una descripción del vehículo
     * @return devuelve dicha descripción
     */
    public String getDescripcion() {
        return descripcion;
    }
    
    /**
     * Método que modifica la decripción del vehículo
     * @param descripcion dato necesario para registrar la descripción del vehículo
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    /**
     * Método que muestra el precio del vehículo
     * @return devuelve el precio del vehículo
     */
    public float getPrecio() {
        return precio;
    }
    
    /**
     * Método que modifica el precio del vehículo
     * @param precio dato necesario para registrar el precio del vehículo
     */
    public void setPrecio(float precio) {
        this.precio = precio;
    }
    
    /**
     * Método que muestra el nombre del propietario del vehículo
     * @return devuelve el nombre del propietario del vehículo
     */
    public String getNombre_propietario() {
        return nombre_propietario;
    }
    
    /**
     * Método que modifica el nombre del propietario del vehículo
     * @param nombre_propietario dato necesario para registrar el nombre del propietario
     * del vehículo
     */
    public void setNombre_propietario(String nombre_propietario) {
        this.nombre_propietario = nombre_propietario;
    }
    
    /**
     * Método que muestra el DNI del propietario del vehículo
     * @return devuelve el DNI del propietario del vehículo
     */
    public String getDni_propietario() {
        return dni_propietario;
    }
    
    /**
     * Método que modifica el DNI del propietario del vehículo
     * @param dni_propietario dato necesario para registrar el DNI del propietario del vehículo
     */
    public void setDni_propietario(String dni_propietario) {
        this.dni_propietario = dni_propietario;
    }   
    
    
    /**
     * Método que muestra al usuario la matrícula del vehículo
     */
    public void imprimirMatricula(){
        System.out.println("Matrícula: "+this.matricula); 
    }
    
    /**
     * Método que muestra al usuario el número de kilómetros del vehículo
     */
    public void imprimirNum_Kilometros(){
        System.out.println("Nº de km: "+this.num_kilometros);
    }
    
    /**
     * Método que actualiza el número de kilómetros del vehículo
     */
    public void actualizarKm(int km){
        this.num_kilometros+=km;
    }
    
    /**
     * Método que muestra los años de antigüedad del vehículo
     * @return devuelve los años de antigüedad del vehículo
     */
    public int getAniosAntiguedad(){
        LocalDate actualidad=LocalDate.now();
        //Restamos los años actuales a los años de la primera fecha de matriculación
        return actualidad.getYear()-fecha_matriculacion.getYear();
    }
    
    /**
     * Método que muestra al usuario los datos del propietario del vehículo 
     */
    public void imprimirNombrePropietario(){
        System.out.println("Propietari@: "+this.nombre_propietario);
    }
    
    /**
     * Método que muestra la descripción del vehículo
     */
    public void imprimirDescripcion(){
        System.out.println("Descripción del vehículo: "+this.descripcion);
    }
    
    /**
     * Método que muestra el precio del vehículo
     */
    public void imprimirPrecio(){
        System.out.println("Precio: "+this.precio);
    }
}