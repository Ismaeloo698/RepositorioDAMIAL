/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PROG06_Ejerc1.util;

/**
 * @author Ismael Argüelles
 */
public class Validar {
    public static void ValidarDNI(String dni) throws excepciones_dni{
        //VALIDAR FORMATO DNI
        //Excepción.Longitud del DNI incorrecta
        if (dni.length()>8 && dni.length()<9){
            throw new excepciones_dni(excepciones_dni.Longitud_incorrecta);
        }
        
        //Tomamos solo los ocho primeros dígitos
        String parteNum=dni.substring(0,8);
        int numeroDNI=0;
        try{
            //Convertimos la parte numérica a numeroDNI
            numeroDNI=Integer.parseInt(parteNum);
        }catch(NumberFormatException errorFormato){
            //Excepción.Error de formato numérico
            throw new excepciones_dni(excepciones_dni.FormatoNum_incorrecto);
        }
        
        //Tomamos solo el último carácter
        char letra=dni.toUpperCase().charAt(8);
        if (!(letra>='A' && letra<='Z')){
            //Excepción.Error de formato en la letra
            throw new excepciones_dni(excepciones_dni.FormatoLetra_incorrecta);
        }
        
        
       
        int resto= numeroDNI%23;
        char letrasDNI[]= {'T','R','W','A','G','M','Y','F','P','D','X','B','N','J','Z','S','Q','V','H','L','C','K','E'};
        String DNI1 = numeroDNI + "" +letrasDNI[resto];
        //Comparo el DNI nuevo con el que me pasa el usuario
        if (!DNI1.equals(dni)){
            //Excepción.Formato de DNI no válido
            throw new excepciones_dni(excepciones_dni.FormatoDNI_incorrecto);
        }
       
    }   
}
