/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PROG06_Ejerc1.util;

/**
 * @author Ismael Argüelles
 */
public class excepciones_dni extends Exception{
    //Excepciones
    public static final String Longitud_incorrecta="ERROR.Debes introducir una longitud del DNI válida";
    public static final String FormatoNum_incorrecto="ERROR.La parte numértica del DNI debe ser solo números";
    public static final String FormatoLetra_incorrecta="ERROR.La parte de la letra del DNI debe ser solo una letra";
    public static final String FormatoDNI_incorrecto="ERROR.El formato del DNI introducido es incorrecto";
    
    /*
    Super() se usa para acceder al atributo de su clase padre; que en este caso es mensaje.
    */
    public excepciones_dni(String mensaje){
        super(mensaje);
    }
    
 
}
