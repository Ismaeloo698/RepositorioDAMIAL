/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package PROG06_Ejerc1;

import PROG06_Ejerc1.util.Validar;
import PROG06_Ejerc1.util.excepciones_dni;
import java.time.LocalDate;
import java.time.Month;
import java.util.Scanner;

/**
 * Programa que permite gestionar vehículos
 * @author Ismael Argüelles
 * @version 1.0
 */
public class Principal {

    /**
     * Función general
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Variables y constantes
        Scanner sc = new Scanner (System.in);
        String resp;
        int opcion=0;
        
        //Se inicia el vehículo en un principio a nulo
        Vehiculo v1 = null;
        //Variables del vehículo
        String nombre_propietario, marca, matricula, descripcion, dni_propietario;
        int num_kilometros;
        float precio;
        int anio, mes, dia;
        LocalDate fecha_matriculacion;
        boolean fechaApto=false, DNIApto=false;
        
        //Menú con las distintas opciones para gestionar el vehículo
        do{
            System.out.println("******GESTIÓN VEHÍCULOS******");
            System.out.println("Bienvenido a la gestión de vehículos, ¿Qué desea hacer?:");
            System.out.println("(1)Nuevo Vehículo\n(2)Ver Matrícula\n(3)Ver Número de Kilómetros\n(4)Actualizar Kilómetros\n"
            + "(5)Ver años de antigüedad\n(6)Mostrar propietario\n(7)Mostrar descripción\n(8)Mostrar precio\n(9)Salir");
            System.out.println("*****************************");
            System.out.println("Elija una opción:");
            opcion=sc.nextInt();
            
            switch(opcion){
                case 1:
                    System.out.println("Vamos a proceder a registrar un nuevo vehículo");
                    System.out.println("Introduzca el nombre del propietario del vehículo");
                    sc.next();
                    nombre_propietario=sc.nextLine();
                    System.out.println("Introduzca la marca de su vehículo");
                    marca=sc.nextLine();
                    System.out.println("Introduzca la matrícula de su vehículo");
                    matricula=sc.nextLine();
                    System.out.println("Introduzca el número de km de su vehículo");
                    num_kilometros=sc.nextInt();
                    System.out.println("Introduzca una descripción de su vehículo");
                    sc.next();
                    descripcion=sc.nextLine();
                    System.out.println("Introduzca el precio de su vehículo");
                    precio=sc.nextFloat();
                    
                    //Fecha de matriculación
                    do{
                        System.out.println("Introduzca la fecha de matriculación del vehículo");
                        System.out.println("Introduzca el año");
                        anio=sc.nextInt();
                        //Leemos una nueva línea para evitar errores de salto de línea
                        sc.nextLine();
                        System.out.println("Introduzca el mes");
                        mes=sc.nextInt();
                        sc.nextLine();
                        System.out.println("Introduzca el día");
                        dia=sc.nextInt();
                        
                        //Restricción mientras la fecha no sea correcta
                        if(anio<1960 && (mes<1 && mes>2) && (dia<1 && dia>31)){//No se tiene en cuenta los años bisiestos
                            System.out.println("La fecha de matriculación introducida es incorrecta");
                            fechaApto=false;
                        }
                        else{
                            fechaApto=true;
                        }
                            
                    }while (fechaApto==false);
                    fecha_matriculacion=LocalDate.of(anio,mes,dia);
                    
                    //DNI del propietario
                    do{
                        System.out.println("Introduzca su DNI");
                        sc.nextLine();
                        dni_propietario=sc.nextLine();
                        //Le paso a la clase validar el DNI del propietario
                        try{
                            Validar.ValidarDNI(dni_propietario);
                            System.out.println("Los datos introducidos son correctos");
                            
                        }catch (excepciones_dni ex){
                           System.out.println(ex.getMessage());
                        }
                        
                    }while(DNIApto);
                    //Una vez pedido todos los datos al usuario creamos el nuevo vehículo
                    v1 = new Vehiculo(marca, matricula, num_kilometros, fecha_matriculacion, descripcion, precio, nombre_propietario, dni_propietario);
                    
                    
                    break;
                    
                //En el caso de que el objeto v1 sea nulo, se tomará dicho vehículo como no registrado
                case 2:
                    if(v1==null){
                        System.out.println("Este coche no está registrado");
                    }
                    else{
                        v1.imprimirMatricula();
                    }
                    break;
                
                case 3:
                    if(v1==null){
                        System.out.println("Este coche no está registrado");
                    }
                    else{
                        v1.imprimirNum_Kilometros();
                    }
                    break;
                
                case 4:
                    if (v1==null){
                        System.out.println("Este coche no está registrado");
                    }
                    else{
                        System.out.println("Escribe los km que quieres añadir:");
                        num_kilometros=sc.nextInt();
                        sc.nextLine();
                        if(num_kilometros>0){
                            v1.actualizarKm(num_kilometros);
                            System.out.println("Se ha sumado al contador: "+num_kilometros+"km");
                        }
                        else{
                            System.out.println("ERROR.No puedes sumar km negativos");
                        }
                    }
                    break;
                    
                case 5:
                    if (v1==null){
                        System.out.println("Este coche no está registrado");
                    }
                    else{
                        System.out.println("Antigüedad: "+v1.getAniosAntiguedad()+" años");
                    }
                    break;
                
                case 6:
                    if (v1==null){
                        System.out.println("Este coche no está registrado");
                    }
                    else{
                       v1.imprimirNombrePropietario();
                    }
                    break;
                
                case 7:
                    if(v1==null){
                        System.out.println("Este coche no está registrado");
                    }
                    else{
                       v1.imprimirDescripcion();
                    }
                    break;
                    
                case 8:
                    if (v1==null){
                        System.out.println("Este coche no está registrado");
                    }
                    else{
                        v1.imprimirPrecio();
                    }
                    break;
                
                case 9:
                    System.out.println("¡Hasta la próxima!");
                    break;
                           
            }
        }while (opcion!=9);
    }
    
}